package com.example.torre.myapplication;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class loadingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                openYourLocalRacesScreen();
            }
        }, 2000);
    }
    public void openYourLocalRacesScreen() {
        Intent intent = new Intent(this, yourLocalRacesActivity.class);
        startActivity(intent);
    }
}
